
    NewProgram.add_command(Command("Forward", 1))
    NewProgram.add_command(Command("backward", 2))
    NewProgram.add_command(Command("left", 3))
    NewProgram.add_command(Command("right", 4))
    NewProgram.add_command(Command("land", 5))

    NewProgram.to_string()


test()
